from socket import *

serverName = '192.168.80.16'
serverPort = 5201

with open('data2000.bin', 'rb') as f:  
    payload = f.read()
print("payload bytes:", len(payload))

clientSocket = socket(AF_INET, SOCK_DGRAM)
clientSocket.sendto(payload, (serverName, serverPort))
print("sent")
clientSocket.close()