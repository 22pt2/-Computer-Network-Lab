from socket import *
serverName = '192.168.80.16'
serverPort = 5201
clientSocket = socket(AF_INET, SOCK_DGRAM)
message = input('Input lowercase sentence:')
clientSocket.sendto(message.encode(), (serverName, serverPort))
modifiedMessage, serverAddress = clientSocket.recvfrom(65535)
print(modifiedMessage.decode())
clientSocket.close()