import socket
import sys

if len(sys.argv) < 3:
    print("用法: python webget.py <host> <path> [port]")
    sys.exit(1)
host, path = sys.argv[1], sys.argv[2]
port = int(sys.argv[3]) if len(sys.argv) > 3 else 80

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(10)                                    
s.connect((host, port))
s.sendall(f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
          f"Connection: close\r\n\r\n".encode())        # T1：带 Connection: close

data = b""
counts = []
while True:
    chunk = s.recv(4096)
    if not chunk:                                       # 结束条件②：对端关闭（EOF）
        break
    counts.append(len(chunk))
    data += chunk
    if b"\r\n\r\n" in data:                             # 结束条件①：按 Content-Length 收够
        head, body = data.split(b"\r\n\r\n", 1)
        cl = [l.split(b":", 1)[1] for l in head.split(b"\r\n")
              if l.lower().startswith(b"content-length:")]
        if cl and len(body) >= int(cl[0]):
            break
s.close()

# ---- T2：按空行拆成 状态行 / 响应头 / body ----
head, body = data.split(b"\r\n\r\n", 1)
lines = head.decode("iso-8859-1").split("\r\n")
print("状态行:", lines[0])
print("状态码:", lines[0].split()[1])
print("响应头:")
for l in lines[1:]:
    print("   ", l)
open("response_body.bin", "wb").write(body)       

# ---- T1/T4：recv 统计 ----
print("recv 次数:", len(counts), "每次字节:", counts)
print("body 字节数:", len(body))