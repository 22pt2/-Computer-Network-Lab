#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
webget.py —— 实验 2 Part D：HTTP 

GitHub 仓库: https://github.com/22pt2/-Computer-Network-Lab

========================================================
------------------------------------------------------------------------------
1. 为什么必须用循环？
   TCP 是"字节流"而不是"消息流"。它只保证字节按序、不丢不重地到达，
   但完全不保留发送方的报文边界：一次 send 可能被拆成多个 TCP 段发出去，
   多次 send 也可能被合并成一次到达；而 recv(n) 的语义是
   "最多给我 n 字节，接收缓冲区里现在有多少就返回多少"——
   它既不会为了凑满 n 字节而等待，也不会告诉你"这是一个完整消息"。
   因此一次 recv 绝不可能保证拿到完整的 HTTP 响应，必须循环接收。

2. 循环靠什么结束？只有两种可能的边界信号：
   【条件①】响应头里有 Content-Length
            → 正文字节数是确定的，收够这么多字节就是收完了，
              不必等对端关闭连接。适用于 keep-alive 连接。
   【条件②】响应头里没有 Content-Length（如 chunked 编码，或服务器发完就关）
            → 没有任何长度信息可用，只能一直收到"对端关闭连接"为止：
              对端 close() 会发 FIN，本端读完全部数据后 recv() 返回空字节串
              b""（即 EOF）。这是 TCP 唯一一种"数据到此为止"的信号。

3. 为了让条件②一定能够触发，请求头里必须显式带上 Connection: close。
   HTTP/1.1 默认是 keep-alive，服务器发完响应不会主动关闭连接，
   如果不带这个头，程序会永远卡在 recv 上。

4. 光有结束条件还不够，还要防止"永远等不到结束条件"：
   用 settimeout(10) 给 socket 设置超时，若 10 秒内既没有新数据、
   也没有收到 EOF，就抛 socket.timeout，程序据此退出，避免挂死。
========================================================
"""

import socket
import sys

TIMEOUT = 10        # socket 超时（秒）：防止挂在一个不关闭连接的坏服务器上
RECV_SIZE = 4096    # 单次 recv 请求的最大字节数（注意：实际返回可能少于它）


def usage():
    """T3：参数不足时打印用法并退出"""
    print("用法: python webget.py <host> <path> [port]")
    print("示例: python webget.py www.bjfu.edu.cn /")
    print("      python webget.py www.bjfu.edu.cn / 80")
    sys.exit(1)


def main():
    # ==================== T3：参数化 ====================
    # host / path / port 全部从命令行读取，代码里不写死任何地址
    if len(sys.argv) < 3:
        usage()

    host = sys.argv[1]                                      # 主机名或 IP
    path = sys.argv[2]                                      # 请求路径，如 /
    port = int(sys.argv[3]) if len(sys.argv) > 3 else 80    # 端口，缺省 80

    # ==================== 建立 TCP 连接 ====================
    # connect() 会触发 TCP 三次握手（SYN → SYN+ACK → ACK），由操作系统内核完成；
    # 应用层只需调用这一个函数，网络上就会产生三个报文。
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(TIMEOUT)       # 关键：不设超时的话，坏服务器会让程序永久阻塞
    print(f"[*] 连接 {host}:{port} ...")
    s.connect((host, port))

    # ==================== 发送 HTTP 请求 ====================
    # 请求由"请求行 + 头部 + 空行"构成，最后一个空行（\r\n\r\n 的后半部分）
    # 是 HTTP 规定用来标记"头部结束"的信号，缺少它服务器会一直等待。
    # Connection: close 的作用见文件头【第 3 点】——为了让结束条件②可靠触发。
    request = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Connection: close\r\n"
        f"\r\n"                      # 这个空行表示头部结束，必须有
    )
    s.sendall(request.encode())

    # ==================== T1：循环 recv，直到收完 ====================
    data = b""          # 累积收到的全部字节
    counts = []         # 记录每次 recv 返回的字节数（T4 观察题要用）

    while True:
        try:
            chunk = s.recv(RECV_SIZE)
        except socket.timeout:
            # 10 秒内既没有新数据也没有 EOF：说明对端既不继续发、也不关闭连接，
            # 属于"坏服务器"。此时必须主动退出循环，否则程序会挂死。
            print("[!] recv 超时，强制结束")
            break

        # ---------- 【结束条件②】对端关闭连接，recv 返回 b""（EOF）----------
        # 当响应没有 Content-Length 时（如 chunked 编码），我们无从知道正文有多长，
        # 唯一可靠的"结束信号"就是对端把连接关掉。
        # 对端 close() → 发 FIN → 本端把剩余数据读完 → 下一次 recv 返回空字节串。
        # 这就是为什么请求里必须带 Connection: close：
        # HTTP/1.1 默认 keep-alive，不带的话服务器发完不会关连接，本端永远收不到 EOF。
        if not chunk:
            print("[*] 收到 EOF（对端关闭连接），接收结束")
            break

        counts.append(len(chunk))
        data += chunk

        # ---------- 判断能不能用【结束条件①】提前收工 ----------
        # 先确认"响应头已经收完整"：HTTP 头部与正文之间用一个空行（\r\n\r\n）分隔，
        # 所以只要 data 里出现了 \r\n\r\n，就说明头部已经全部到齐、可以解析了。
        if b"\r\n\r\n" in data:
            head, body = data.split(b"\r\n\r\n", 1)     # 只按第一个空行切一次
            # 在头部里找 Content-Length（大小写不敏感，值可能带前导空格）
            cl = [l.split(b":", 1)[1] for l in head.split(b"\r\n")
                  if l.lower().startswith(b"content-length:")]

            # ---------- 【结束条件①】按 Content-Length 收够就停 ----------
            # 有 Content-Length 说明正文字节数已声明，只要已收 body 长度 >= 声明值
            # 就判定"收完了"，无需等待对端关闭连接（keep-alive 场景必须靠这个退出）。
            # 这里用 >= 而不是 ==，因为一次 recv 可能连带收到后面的字节，
            # 用 >= 更稳妥，不会因为多收而漏判。
            if cl and len(body) >= int(cl[0]):
                print(f"[*] 已按 Content-Length={int(cl[0])} 收够，接收结束")
                break

    s.close()

    # ==================== T2：按空行拆分 状态行 / 响应头 / body ====================
    # HTTP 响应的结构是：状态行 + 若干响应头 + 空行 + 正文，
    # 所以按第一个 \r\n\r\n 切开，前半部分是头部、后半部分是正文。
    head, body = data.split(b"\r\n\r\n", 1)
    lines = head.decode("iso-8859-1").split("\r\n")     # 头部按字节保真解码，避免中文乱码
    print("状态行:", lines[0])                          # 如 HTTP/1.1 200 OK
    print("状态码:", lines[0].split()[1])               # 如 200
    print("响应头:")
    for l in lines[1:]:
        print("   ", l)

    # body 必须用二进制模式（"wb"）写文件：
    # 文本模式（"w"）在 Windows 下会把 \n 转成 \r\n（凭空多出 0x0D 字节），
    # 还会按编码解码再编码，图片/压缩包这类任意字节流会被破坏。
    # "wb" 不做任何转换，字节原样落盘，所以图片、PDF、zip 都能完整保存。
    open("response_body.bin", "wb").write(body)

    # ==================== T1 验收 + T4 观察题数据 ====================
    # recv 次数远大于 1，且每次字节数大小不一，这正说明：
    # TCP 不保留报文边界，应用层无法"一次 recv 收完整条消息"。
    print("recv 次数:", len(counts), "每次字节:", counts)
    print("body 字节数:", len(body))


if __name__ == "__main__":
    main()