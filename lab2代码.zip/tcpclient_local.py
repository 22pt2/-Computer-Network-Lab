import socket

serverName = '127.0.0.1'
serverPort = 5202
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((serverName, serverPort))
s.send(input('Input lowercase sentence:').encode())
print('From Server:', s.recv(1024).decode())
s.close()