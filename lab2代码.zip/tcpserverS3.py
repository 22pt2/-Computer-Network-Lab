from socket import *
import time

serverPort = 5202
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('', serverPort))
serverSocket.listen(1)
print('S3 server is ready to receive')

while True:
    connectionSocket, addr = serverSocket.accept()
    print("connected from:", addr)
    sentence = connectionSocket.recv(1024).decode()
    print("recv:", sentence)
    connectionSocket.send(sentence.upper().encode())
    print("data sent. waiting for client to close ...")

    try:
        rest = connectionSocket.recv(1024)
        print("client closed NORMALLY, recv returned:", rest)
    except ConnectionResetError as e:
        print("client ABORTED (RST received):", e)

    print("sleeping 60s, now run:  ss -tan | grep 5202")
    time.sleep(60)
    connectionSocket.close()
    print("socket closed")
