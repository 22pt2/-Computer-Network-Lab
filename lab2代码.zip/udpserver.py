from socket import *

serverPort = 5201
serverSocket = socket(AF_INET, SOCK_DGRAM)
serverSocket.bind(('', serverPort))
print("UDP server ready, listening on", serverPort)

while True:
    message, clientAddress = serverSocket.recvfrom(65535)
    print("recv", len(message), "bytes from", clientAddress)
    reply = message.upper()                     
    serverSocket.sendto(reply, clientAddress)
