from socket import *
import os

serverName = '192.168.80.16'
serverPort = 5202
clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect((serverName, serverPort))

sentence = input('Input lowercase sentence:')
clientSocket.send(sentence.encode())
modifiedSentence = clientSocket.recv(1024)
print('From Server:', modifiedSentence.decode())

print("=" * 46)
print("连接保持中！我的进程 PID =", os.getpid())
print("请到另一个窗口杀掉这个进程，不要在这里按回车")
print("=" * 46)
input()          # 停在这里，等你杀掉进程
clientSocket.close()
print("正常关闭了连接（对照组用这个）")