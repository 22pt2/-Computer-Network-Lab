import socket

serverPort = 5202
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.bind(('', serverPort))
serverSocket.listen(1)
print('TCP server ready on', serverPort)

while True:
    conn, addr = serverSocket.accept()
    print('connected:', addr)
    data = conn.recv(1024).decode()
    print('recv:', data)
    conn.send(data.upper().encode())
    conn.close()